هذا المجلد مخصص لملفات الزخارف (png/svg).
يمكنك إضافة ملفات drawable هنا، مثل header_pattern.png, border.svg.
