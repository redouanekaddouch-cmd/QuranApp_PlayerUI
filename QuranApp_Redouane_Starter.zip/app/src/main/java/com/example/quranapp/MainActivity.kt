package com.example.quranapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.quranapp.data.QuranRepository
import com.example.quranapp.data.Sura

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = QuranRepository(applicationContext)
        val suras = repo.loadAll()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HomeScreen(suras = suras, onOpen = { /* open reader - placeholder */ })
                }
            }
        }
    }
}

@Composable
fun HomeScreen(suras: List<Sura>, onOpen: (Sura) -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        Text("القرآن الكريم مرتلا", style = MaterialTheme.typography.h5)
        Spacer(Modifier.height(8.dp))
        LazyColumn { items(suras.size) { idx ->
            val s = suras[idx]
            Card(modifier = Modifier.fillMaxWidth().padding(4.dp)) {
                Row(modifier = Modifier.padding(12.dp)) {
                    Text(text = "${'$'}{s.index}. ${'$'}{s.name}")
                }
            }
        }}
    }
}
