package com.example.quranapp.data

import kotlinx.serialization.Serializable

@Serializable
data class Aya(
    val sura: Int,
    val aya: Int,
    val text: String
)

@Serializable
data class Sura(
    val index: Int,
    val name: String,
    val ayat: List<Aya>
)
