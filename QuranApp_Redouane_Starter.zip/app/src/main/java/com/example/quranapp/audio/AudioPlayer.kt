package com.example.quranapp.audio

import android.content.Context
import android.net.Uri
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem

class AudioPlayer(private val ctx: Context) {
    private val player = ExoPlayer.Builder(ctx).build()

    fun playAssetUri(uri: Uri) {
        val mediaItem = MediaItem.fromUri(uri)
        player.setMediaItem(mediaItem)
        player.prepare()
        player.play()
    }

    fun pause() { player.pause() }
    fun stop() { player.stop() }
    fun release() { player.release() }
}
