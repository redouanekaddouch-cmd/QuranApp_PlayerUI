package com.example.quranapp.data

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

class QuranRepository(private val ctx: Context) {
    private var suras: List<Sura>? = null

    fun loadAll(): List<Sura> {
        if (suras != null) return suras!!
        val json = ctx.assets.open("quran_text.json").bufferedReader().use { it.readText() }
        suras = Json.decodeFromString(json)
        return suras!!
    }

    fun search(query: String): List<Aya> {
        val q = query.trim().lowercase()
        return loadAll().flatMap { it.ayat }.filter { it.text.contains(q, ignoreCase = true) }
    }
}
