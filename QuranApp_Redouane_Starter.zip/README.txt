QuranApp - Starter project
=========================

App name: القرآن الكريم مرتلا
Theme colors: أخضر و ذهبي (please customize in styles)

Included:
- Minimal Kotlin + Jetpack Compose starter files
- assets/quran_text.json (sample: الفاتحة و3 آيات من البقرة)
- tiny demo WAV files for two 'reciters' in assets/audio/ (for testing only)
- instructions in this README to continue development.

Next steps for you (recommended):
1. Open this project folder in Android Studio (Import project).
2. Replace demo audio files with licensed MP3/WAV recitations and keep naming convention:
   assets/audio/<reciter_slug>/<sura3digits>_<aya3digits>.ext
3. Expand quran_text.json to include the full Mushaf (or use an efficient DB approach).
4. Add proper UI assets: drawables, fonts (e.g., Noto Naskh Arabic), and style theme (green/gold).
5. Test offline playback and consider using Expansion Files if audio data becomes large.
6. Respect copyrights and get permission to redistribute recitations if you plan to publish the app.

If you want, I can now:
- generate the full quran_text.json (this will be large),
- add code for bookmarking, search UI, and player controls,
- or prepare an APK (note: building APK must be done in Android Studio on your machine).
